Link to GitHub repository:
https://github.com/gafeol/Mobile

Project for the shopping list is in the folder ShoppingList.

Team Androidão:
Gabriel Fernandes de Oliveira
Ivan Fontana
Pedro Henrique Barbosa de Almeida