Homework 4  - User Navigation

Androidão Team: 
Gabriel Fernandes de Oliveira
Ivan Fontana
Pedro Henrique Barbosa de Almeida

Link to the GitHub where the code is hosted: https://github.com/gafeol/Mobile/tree/master/H04

Icons ownership:

 - Lego and Tennis ball icons made by https://www.flaticon.com/authors/smashicons from www.flaticon.com

 - Fusca car icon made by https://www.flaticon.com/authors/pixel-buddha from www.flaticon.com

 - All other icons made by https://www.flaticon.com/authors/freepik from https://www.flaticon.com/" 
