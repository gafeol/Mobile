Homework 5  - AsyncTask and AsyncTaskLoader

Androidão Team: 
Gabriel Fernandes de Oliveira
Ivan Fontana
Pedro Henrique Barbosa de Almeida

Link to the GitHub where the code is hosted: https://github.com/gafeol/Mobile/tree/master/H05
