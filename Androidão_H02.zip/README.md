Link to GitHub repository:
https://github.com/gafeol/Mobile

Team Androidão:
Gabriel Fernandes de Oliveira
Ivan Fontana
Pedro Henrique Barbosa de Almeida

Macaw icon made by Freepik from www.flaticon.com.
